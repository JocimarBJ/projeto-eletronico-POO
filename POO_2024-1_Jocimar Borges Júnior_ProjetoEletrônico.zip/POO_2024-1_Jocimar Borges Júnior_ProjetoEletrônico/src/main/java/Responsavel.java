//Jocimar Borges Júnior, RA: 2565897

public interface Responsavel {
        // Métodos para mostrar os responsáveis pela venda e pelo produto
        public void definirVendedor(String vendedor);
        public String getVendedor();
        public void definirGerente(String gerente);
        public String getGerente();
}
